package Charecters.Students;

import Charecters.Student;

public class Kissi extends Student {
    public Kissi() {
        super(30, 5, 10, 10);
    }
    public static Student Kissi_N = new Kissi();
}
