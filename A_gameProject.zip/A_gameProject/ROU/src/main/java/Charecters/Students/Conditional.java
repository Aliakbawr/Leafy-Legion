package Charecters.Students;

import Charecters.Student;

public class Conditional extends Student {
    public Conditional() {
        super(20, 20, 60, 15);
    }
    public static Student Conditional_N = new Conditional();
}
