package Charecters.Students;

import Charecters.Student;

public class Nerd extends Student {
    public Nerd() {
        super(20, 30, 40, 10);
    }
    public static Student Nerd_N = new Nerd();
}
