package Charecters.Students;

import Charecters.Student;

public class Stupid extends Student {
    public Stupid() {
        super(5, 60, 50, 7);
    }
    public static Student Stupid_N = new Stupid();
}
