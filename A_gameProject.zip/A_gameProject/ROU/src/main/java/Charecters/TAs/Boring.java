package Charecters.TAs;

import Charecters.TA;

public class Boring extends TA {
    public Boring() {
        super(20, 10, 60);
    }
    public static TA Boring_N = new Boring();
}
