package Charecters.TAs;

import Charecters.TA;

public class Angry extends TA {
    public Angry() {
        super(20, 20, 40);
    }
    public static TA Angry_N = new Angry();
}
