package Charecters.TAs;

import Charecters.TA;

public class Normal extends TA {
    public Normal() {
        super(20, 20, 40);
    }
    public static TA Normal_N = new Normal();
}
