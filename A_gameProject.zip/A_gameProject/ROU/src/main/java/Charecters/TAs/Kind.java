package Charecters.TAs;

import Charecters.TA;

public class Kind extends TA {
    public Kind() {
        super(5, 15, 60);
    }
    public static TA Kind_N = new Kind();
}
